package org.example.adapter;

public interface IPlayStationController {
    void pressButtonTriangle();
    void pressButtonSquare();
    void pressButtonCircle();
    void pressButtonX();
    void pressLeftButton();
    void pressRightButton();
}
