package org.example.adapter;

public interface IXboxController {
    void pressButtonA();
    void pressButtonB();
    void pressButtonX();
    void pressButtonY();
    void pressLeftButton();
    void pressRightButton();
}
