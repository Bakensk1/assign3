package org.example.observer;

public interface CharacterObserver {
    void onEvent(String eventName);
}
