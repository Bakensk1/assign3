package org.example.observer;

public interface IEventPublisher {
    static void addObserver(CharacterObserver observer) {

    }

    static void removeObserver(CharacterObserver observer) {

    }
}
