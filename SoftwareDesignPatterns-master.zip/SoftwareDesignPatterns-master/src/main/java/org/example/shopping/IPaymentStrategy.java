package org.example.shopping;

public interface IPaymentStrategy {
    void processPayment(double amount);
}
